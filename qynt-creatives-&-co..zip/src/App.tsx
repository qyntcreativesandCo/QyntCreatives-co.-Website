/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useInView } from 'motion/react';
import { Menu, X, ArrowRight, Instagram, Twitter, Linkedin, Mail, ChevronDown } from 'lucide-react';

// --- Components ---

const Marquee = ({ items, speed = 20 }: { items: string[], speed?: number }) => {
  return (
    <div className="relative flex overflow-x-hidden border-y border-white/10 bg-black py-12">
      <motion.div
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: speed, repeat: Infinity, ease: 'linear' }}
        className="flex whitespace-nowrap"
      >
        {[...items, ...items].map((item, idx) => (
          <span key={idx} className="mx-12 text-4xl md:text-6xl font-bold uppercase tracking-tighter opacity-20 hover:opacity-100 transition-opacity cursor-default">
            {item}
          </span>
        ))}
      </motion.div>
    </div>
  );
};

const MouseFollower = () => {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  return (
    <motion.div
      className="fixed top-0 left-0 pointer-events-none z-[100] mix-blend-difference"
      animate={{ x: mousePos.x - 20, y: mousePos.y - 30 }}
      transition={{ type: 'spring', damping: 20, stiffness: 150, mass: 0.5 }}
    >
      <span className="text-6xl font-bold text-white opacity-80">Q</span>
    </motion.div>
  );
};

const IntroScreen = ({ onComplete }: { onComplete: () => void; key?: string }) => {
  const [count, setCount] = useState(3);
  const [isEntering, setIsEntering] = useState(false);

  useEffect(() => {
    if (count > 0) {
      const timer = setTimeout(() => setCount(count - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setIsEntering(true);
      const timer = setTimeout(onComplete, 1500);
      return () => clearTimeout(timer);
    }
  }, [count, onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black text-white overflow-hidden"
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
    >
      {/* Background elements for "best" look */}
      <div className="absolute inset-0 opacity-20">
        <motion.div 
          animate={{ 
            scale: [1, 1.2, 1],
            rotate: [0, 90, 180, 270, 360]
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute top-[-10%] left-[-10%] w-[120%] h-[120%] border-[1px] border-white/10 rounded-full"
        />
      </div>

      <AnimatePresence mode="wait">
        {!isEntering ? (
          <motion.div
            key="counter"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.2, filter: 'blur(20px)' }}
            className="flex flex-col items-center"
          >
            <motion.div
              key={count}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="text-[15vw] font-bold tracking-tighter leading-none"
            >
              {count}
            </motion.div>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="mt-4 text-xs tracking-[1em] uppercase opacity-40"
            >
              Initializing Vibe
            </motion.div>
          </motion.div>
        ) : (
          <motion.div
            key="reveal"
            initial={{ opacity: 0, letterSpacing: "2em" }}
            animate={{ opacity: 1, letterSpacing: "0.5em" }}
            className="text-2xl md:text-4xl font-bold uppercase tracking-[0.5em] text-center px-6 glitch-text"
            data-text="QYNT CREATIVES & CO."
          >
            QYNT CREATIVES & CO.
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ duration: 3, ease: "easeInOut" }}
        className="absolute bottom-0 left-0 w-full h-1 bg-white origin-left"
      />
    </motion.div>
  );
};

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Portfolio', href: '#portfolio' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-40 transition-all duration-500 ${scrolled ? 'bg-black/80 backdrop-blur-md py-4' : 'bg-transparent py-8'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <motion.a 
          href="#" 
          className="text-2xl font-bold tracking-tighter"
          whileHover={{ scale: 1.05 }}
        >
          QYNT<span className="font-light italic"> CREATIVES</span>
        </motion.a>

        {/* Desktop Nav */}
        <div className="hidden md:flex space-x-12">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm uppercase tracking-widest hover:text-gray-400 transition-colors relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-px bg-white transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-black border-b border-white/10 p-8 md:hidden"
          >
            <div className="flex flex-col space-y-6 items-center">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsOpen(false)}
                  className="text-lg uppercase tracking-widest"
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const opacity = useTransform(scrollY, [0, 300], [1, 0]);

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Video Placeholder / Abstract Visual */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-black/60 z-10" />
        <video
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover grayscale"
          referrerPolicy="no-referrer"
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-abstract-ink-flow-in-water-34440-large.mp4" type="video/mp4" />
        </video>
      </div>

      <motion.div 
        style={{ y: y1, opacity }}
        className="relative z-20 text-center px-6"
      >
        <motion.h1 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="text-6xl md:text-9xl font-bold tracking-tighter mb-4 leading-[0.9]"
        >
          Qynt Creatives <br /> & Co.
        </motion.h1>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1 }}
          className="text-lg md:text-2xl font-light tracking-[0.3em] uppercase opacity-80"
        >
          Designing the Future in Monochrome.
        </motion.p>
      </motion.div>

      <motion.div 
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 opacity-50"
      >
        <ChevronDown size={32} />
      </motion.div>
    </section>
  );
};

const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-32 px-6 bg-white text-black">
      <div className="max-w-5xl mx-auto" ref={ref}>
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-sm uppercase tracking-[0.5em] mb-12 opacity-50">Our Essence</h2>
          <p className="text-3xl md:text-5xl font-light leading-tight mb-12">
            We are a collective of visionaries, designers, and storytellers who believe that <span className="font-bold">simplicity</span> is the ultimate sophistication. By stripping away the noise, we reveal the <span className="italic">soul</span> of every brand we touch.
          </p>
          <div className="grid md:grid-cols-2 gap-12 text-lg opacity-80 font-light">
            <p>
              Founded on the principles of minimalism and high-contrast aesthetics, QyntCreative & Co. has spent a decade redefining luxury in the digital age. We don't just build websites; we craft digital experiences that resonate on a primal level.
            </p>
            <p>
              Our approach is cinematic, our execution is surgical, and our results are timeless. In a world of fleeting colors, we choose the permanence of black and white.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

const Services = () => {
  const services = [
    { title: 'Branding & Identity', desc: 'Crafting unique visual signatures that command attention.' },
    { title: 'Web Design & Development', desc: 'Immersive web and mobile platforms built for the future.' },
    { title: 'Digital Marketing', desc: 'Strategic growth through data-driven digital campaigns.' },
    { title: 'SEO (Search Engine Optimization)', desc: 'Search Engine Optimization to dominate the digital landscape.' },
    { title: 'Video & Motion', desc: 'Cinematic animations that bring static concepts to life.' },
    { title: 'Content Creation', desc: 'Compelling storytelling across all digital mediums.' },
    { title: 'Advertising', desc: 'High-impact campaigns that convert and resonate.' },
    { title: 'Packaging Design', desc: 'Tangible brand experiences that stand out on the shelf.' },
    { title: 'Strategy & Consulting', desc: 'Expert guidance to navigate the complex creative world.' },
    { title: 'UI/UX Design', desc: 'User-centric interfaces that blend beauty with functionality.' },
  ];

  return (
    <section id="services" className="py-32 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <h2 className="text-sm uppercase tracking-[0.5em] mb-24 opacity-50 text-center">Capabilities</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/10">
          {services.map((service, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ backgroundColor: 'rgba(255,255,255,1)', color: '#000' }}
              className="bg-black p-12 transition-colors duration-500 group cursor-default"
            >
              <span className="text-xs font-mono mb-8 block opacity-50">{idx < 9 ? `0${idx + 1}` : idx + 1}</span>
              <h3 className="text-2xl font-bold mb-4 uppercase tracking-tighter">{service.title}</h3>
              <p className="text-sm font-light leading-relaxed opacity-60 group-hover:opacity-100 transition-opacity">
                {service.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Portfolio = () => {
  const projects = [
    { title: 'Ethereal', category: 'Motion', img: 'https://picsum.photos/seed/ethereal/800/1000?grayscale' },
    { title: 'Monolith', category: 'Branding', img: 'https://picsum.photos/seed/monolith/800/1000?grayscale' },
    { title: 'Vortex', category: 'Digital', img: 'https://picsum.photos/seed/vortex/800/1000?grayscale' },
    { title: 'Silence', category: 'Art Direction', img: 'https://picsum.photos/seed/silence/800/1000?grayscale' },
  ];

  return (
    <section id="portfolio" className="py-32 px-6 bg-white text-black">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-24">
          <h2 className="text-sm uppercase tracking-[0.5em] opacity-50">Selected Works</h2>
          <motion.button 
            whileHover={{ x: 10 }}
            className="flex items-center gap-2 text-sm uppercase tracking-widest font-bold"
          >
            View All <ArrowRight size={16} />
          </motion.button>
        </div>
        <div className="grid md:grid-cols-2 gap-12">
          {projects.map((project, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="overflow-hidden mb-6 aspect-[4/5] bg-gray-100">
                <motion.img 
                  src={project.img} 
                  alt={project.title}
                  referrerPolicy="no-referrer"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.8, ease: [0.43, 0.13, 0.23, 0.96] }}
                  className="w-full h-full object-cover grayscale"
                />
              </div>
              <div className="flex justify-between items-center">
                <h3 className="text-2xl font-bold tracking-tighter uppercase">{project.title}</h3>
                <span className="text-xs uppercase tracking-widest opacity-50">{project.category}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => {
  return (
    <section id="contact" className="py-32 px-6 bg-black">
      <div className="max-w-5xl mx-auto">
        <div className="grid md:grid-cols-2 gap-24">
          <div>
            <h2 className="text-sm uppercase tracking-[0.5em] mb-12 opacity-50">Inquiries</h2>
            <h3 className="text-5xl md:text-7xl font-bold tracking-tighter mb-12 uppercase leading-none">
              Let's Create <br /> The Future.
            </h3>
            <div className="space-y-4 text-lg font-light opacity-60">
              <p>Qyntcreatives@gmail.com</p>
              <p>9627277111</p>
              <p>Sector 105 D block Noida</p>
            </div>
            <div className="flex gap-6 mt-12">
              <motion.a whileHover={{ y: -5 }} href="#" className="opacity-50 hover:opacity-100 transition-opacity"><Instagram /></motion.a>
              <motion.a whileHover={{ y: -5 }} href="#" className="opacity-50 hover:opacity-100 transition-opacity"><Twitter /></motion.a>
              <motion.a whileHover={{ y: -5 }} href="#" className="opacity-50 hover:opacity-100 transition-opacity"><Linkedin /></motion.a>
            </div>
          </div>
          <form className="space-y-12">
            <div className="relative group">
              <input 
                type="text" 
                placeholder="Name" 
                className="w-full bg-transparent border-b border-white/20 py-4 outline-none focus:border-white transition-colors placeholder:uppercase placeholder:text-xs placeholder:tracking-widest"
              />
              <motion.div className="absolute bottom-0 left-0 h-px bg-white w-0 group-focus-within:w-full transition-all duration-500" />
            </div>
            <div className="relative group">
              <input 
                type="email" 
                placeholder="Email" 
                className="w-full bg-transparent border-b border-white/20 py-4 outline-none focus:border-white transition-colors placeholder:uppercase placeholder:text-xs placeholder:tracking-widest"
              />
              <motion.div className="absolute bottom-0 left-0 h-px bg-white w-0 group-focus-within:w-full transition-all duration-500" />
            </div>
            <div className="relative group">
              <textarea 
                rows={4}
                placeholder="Message" 
                className="w-full bg-transparent border-b border-white/20 py-4 outline-none focus:border-white transition-colors placeholder:uppercase placeholder:text-xs placeholder:tracking-widest resize-none"
              />
              <motion.div className="absolute bottom-0 left-0 h-px bg-white w-0 group-focus-within:w-full transition-all duration-500" />
            </div>
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-white text-black py-6 uppercase tracking-[0.3em] font-bold text-sm hover:bg-gray-200 transition-colors"
            >
              Send Message
            </motion.button>
          </form>
        </div>
      </div>
    </section>
  );
};

const Footer = () => {
  return (
    <footer className="py-12 px-6 border-t border-white/10 bg-black text-center">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
        <p className="text-xs uppercase tracking-widest opacity-40">
          © 2026 Qynt Creatives & Co. All Rights Reserved.
        </p>
        <div className="flex gap-12 text-xs uppercase tracking-widest opacity-40">
          <a href="#" className="hover:opacity-100 transition-opacity">Privacy Policy</a>
          <a href="#" className="hover:opacity-100 transition-opacity">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default function App() {
  const [showIntro, setShowIntro] = useState(true);

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {showIntro ? (
          <IntroScreen key="intro" onComplete={() => setShowIntro(false)} />
        ) : (
          <motion.main
            key="main"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <MouseFollower />
            <Navbar />
            <Hero />
            <Marquee items={['roadhouse cafe', 'Mannsebymansi', 'chartainternational', 'zenzy technologies', 'metal cat music', 'gig lab soundworks', 'Chskd College', 'App star']} speed={30} />
            <About />
            <Marquee items={['Branding', 'Development', 'Marketing', 'SEO', 'Video', 'Content', 'Advertising', 'Packaging', 'Strategy', 'UI/UX']} speed={30} />
            <Services />
            <Portfolio />
            <Marquee items={['NO CAP', 'MAIN CHARACTER ENERGY', 'GOAT CREATIVES', 'VIBE CHECK', 'SLAY', 'PERIODT']} speed={40} />
            <Contact />
            <Footer />
          </motion.main>
        )}
      </AnimatePresence>
    </div>
  );
}
